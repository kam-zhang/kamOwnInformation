#include "show.h"

int show(int value)
{
    return value;
}

