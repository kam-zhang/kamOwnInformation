#ifndef _SHOW_H
#define _SHOW_H

int show(int value);

#endif
